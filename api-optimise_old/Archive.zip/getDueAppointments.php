Last login: Tue Jul 26 10:44:57 on ttys000
dyn1244-143:~ myyong$ ssh ubuntu@146.169.32.150
Welcome to Ubuntu 14.04.3 LTS (GNU/Linux 3.13.0-74-generic x86_64)

 * Documentation:  https://help.ubuntu.com/

  System information as of Tue Jul 26 02:49:11 UTC 2016

  System load:  0.27              Processes:           143
  Usage of /:   83.3% of 9.81GB   Users logged in:     0
  Memory usage: 14%               IP address for eth0: 10.0.1.5
  Swap usage:   0%

  Graph this data and manage this system at:
    https://landscape.canonical.com/

  Get cloud support with Ubuntu Advantage Cloud Guest:
    http://www.ubuntu.com/business/services/cloud

187 packages can be updated.
123 updates are security updates.


Last login: Tue Jul 26 02:49:13 2016 from dyn1187-209.wlan.ic.ac.uk
ubuntu@eti-dev-tmxnat:~$ emacs /var/www/api-optimise/getDueAppointments.php































File Edit Options Buffers Tools Help

        function getUSUBJID($doc) {
                 for ($d = 0; $d < count($doc); $d++) {
                     if    ($doc[$d]["fieldName"]=="USUBJID")
                           return $doc[$d]["value"];
                 }
                 return "empty";
        }

        function getDOMAIN($doc) {
                 for ($d = 0; $d < count($doc); $d++) {
                     if    ($doc[$d]["fieldName"]=="DOMAIN")
                           return $doc[$d]["value"];
                 }
                 return "empty";
        }


        function sortBySubjects($USUBJID, $type, $DTC) {
                 global $subjects;
                 /*
                 if (!array_key_exists($USUBJID, $subjects)) {
                    $subjecs[$USUBJID][$type]=array();
                }*/
                //print_r($subjects);

                 $subjects[$USUBJID][$type][]= $DTC;
        }
        /*
        $cursor = $optimise->find(array ('$or' => array (0 => array ('PRTRT' => 'MRI'),
                                        1 => array ('PRTRT' => 'Lumbar Puncture'),
                                        2 => array ('DOMAIN' => 'IS'),
                                        3 => array ('DOMAIN' => 'LB'),
                                        4 => array ('NVCAT' => 'Evoked Potential'))));
                                        */

	$reminders_cursor = $reminders->find({});
	foreach	($reminders_cursor as $reminder) {

        }
        var user_id = myCursor.hasNext() ? myCursor.next() : null;
        db.posts.find({owner_id : user_id._id});

        $cursor = $optimise->find(array ('$or' => array (0 => array ('DOMAIN' => 'IS'),
                                        1 => array ('DOMAIN' => 'LB'))));

        //$remindersList = $reminders
        foreach ($cursor as $id => $valueRoot) {
                $recordItems = array();
                foreach ($valueRoot as $key => $value) {
                        $recordItems[] = array('fieldName' => $key, 'value' => $value);
                }
                $RecordSet[] = array('RecordItems' => $recordItems);
-UU-:----F1  getDueAppointments.php   21% L93    (Fundamental) ----------------------------------------------------------------------------------------------------------------------
Wrote /var/www/api-optimise/getDueAppointments.php
