<?php
/**
 * Created by PhpStorm.
 * User: Yang
 * Date: 25/01/2016
 * Time: 11:02
 */

include_once("../config.php");
include_once("../utilities.php");

define ("ICOMETRIX_TABLE", "jobs");
define ("ICOMETRIX_DB", "icometrix");

$connection = db_connect(ICOMETRIX_DB);
$icometrix = $connection->selectCollection(ICOMETRIX_TABLE);

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $data = file_get_contents('php://input'); //get POST payload=
    $json = json_decode($data, true);
    if ($json == null) {
        echo "JSON ERROR";
        return;
    }

    if (isset($json['RecordSet'])) {   //inserting new document
        $RecordSet = $json['RecordSet'];
        for ($i = 0; $i < count($RecordSet); $i++) {
        if (isset($RecordSet[$i]['RecordItems'])) {
            $mongoItem = array();
            for ($j = 0; $j < count($RecordSet[$i]['RecordItems']); $j++) {
                $subItem = $RecordSet[$i]['RecordItems'][$j];
                if (isset($subItem) && isset($subItem['fieldName']) && isset($subItem['value'])) {
                    $fieldName = $RecordSet[$i]['RecordItems'][$j]['fieldName'];
                    $value = $RecordSet[$i]['RecordItems'][$j]['value'];
                    $mongoItem[$fieldName] = $value;
                }
            }
            if (count($mongoItem) > 0) {
                $result = $icometrix->insert($mongoItem);
            }
        }
    }
    echo "RECORD(s) SUCCESSFULLY INSERTED";
    return;
}
else {
    echo "UNKNOWN METHOD";
}




